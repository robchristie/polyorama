import hashlib
import json
from pathlib import Path
import subprocess
root=Path.cwd()
source=root/'crates/polyorama-core/src/lib.rs'
original=source.read_bytes()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
command=['cargo','test','--doc','-p','polyorama-core']
try:
    broken=original.replace(b'//! use polyorama_core::{CommandHistory,', b'//! use polyorama_core::{MissingCommandHistory,',1)
    assert broken != original
    source.write_bytes(broken)
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (root/'.tools/runtime/api-documentation/broken-example-output.log').write_text(result.stdout)
    assert result.returncode != 0, 'broken selected example unexpectedly passed'
    assert 'unresolved import' in result.stdout and 'MissingCommandHistory' in result.stdout
finally:
    source.write_bytes(original)
assert source.read_bytes()==original
receipt={'source_commit':revision,'command':command,'environment':'Rust 1.98.1 native doctest route; isolated implementation worktree; one deliberately unresolved selected crate-example import', 'returncode':result.returncode,'intended_failure':'unresolved import polyorama_core::MissingCommandHistory','source_restored_sha256':hashlib.sha256(original).hexdigest(),'fault_retained':False,'log':'broken-example-output.log'}
(root/'.tools/runtime/api-documentation/broken-example-probe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
