import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
name,*command=sys.argv[1:]
root=Path.cwd()
evidence=root/'.tools/runtime/api-documentation'
sysroot=root/'.tools/sysroot'
private=Path(tempfile.mkdtemp(prefix='headful-'+name+'-',dir=root/'.tools/runtime'))
private.chmod(0o1777)
(private/'.X11-unix').mkdir(mode=0o1777)
(private/'.X11-unix').chmod(0o1777)
env={**os.environ,'LD_LIBRARY_PATH':str(sysroot/'usr/lib'),'DISPLAY':':'+str(1000+os.getpid()%10000),'POLYORAMA_BROWSER_HEADFUL':'1','POLYORAMA_USE_SYSTEM_UI_LIBS':'1','RUSTUP_TOOLCHAIN':'1.98.1','PATH':'/home/rob/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin:'+os.environ['PATH']+':/opt'}
sandbox=['bwrap','--unshare-pid','--die-with-parent','--ro-bind','/','/','--bind',str(private),'/tmp','--ro-bind','/usr/bin','/opt','--ro-bind',str(root/'.tools/runtime/headful-bin'),'/usr/bin','--bind',str(root),str(root),'--bind',str((root/'target').resolve()),str((root/'target').resolve()),'--bind','/home/rob','/home/rob','--dev-bind','/dev','/dev','--proc','/proc']
def output(*args): return subprocess.check_output(args,text=True).strip()
record={'command':command,'cwd':str(root),'revision':output('git','rev-parse','HEAD'),'tree':output('git','rev-parse','HEAD^{tree}'),'status_before':output('git','status','--porcelain'),'host':platform.platform(),'rustc':output('rustc','-Vv'),'cargo':output('cargo','-V'),'node':output('node','--version'),'npm':output('npm','--version'),'wasm_bindgen':output('wasm-bindgen','--version'),'environment':{key:env[key] for key in ('RUSTUP_TOOLCHAIN','LD_LIBRARY_PATH','POLYORAMA_USE_SYSTEM_UI_LIBS','POLYORAMA_BROWSER_HEADFUL','DISPLAY')},'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
start=time.monotonic()
with (evidence/(name+'-xvfb.log')).open('w') as xlog:
    xvfb=subprocess.Popen(sandbox+[str(sysroot/'usr/bin/Xvfb'),env['DISPLAY'],'-screen','0','1440x900x24','-nolisten','tcp','+extension','GLX'],stdout=xlog,stderr=subprocess.STDOUT,env=env)
    try:
        time.sleep(1)
        if xvfb.poll() is not None: raise RuntimeError('headful Xvfb failed')
        with (evidence/(name+'.log')).open('w') as log:
            log.write(json.dumps(record,indent=2)+'\n');log.flush()
            result=subprocess.run(sandbox+command,env=env,stdout=log,stderr=subprocess.STDOUT)
    finally:
        if xvfb.poll() is None:
            xvfb.terminate()
            try:xvfb.wait(timeout=10)
            except subprocess.TimeoutExpired:xvfb.kill();xvfb.wait()
        shutil.rmtree(private)
record.update(exit_code=result.returncode,elapsed_seconds=round(time.monotonic()-start,3),status_after=output('git','status','--porcelain'),finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(evidence/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(result.returncode)
