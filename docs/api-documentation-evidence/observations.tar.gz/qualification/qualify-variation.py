import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
root=Path.cwd()
source=root/'apps/analytical-workspace-lab/examples/minimal-workspace.rs'
original=source.read_bytes()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
output=root/'.tools/runtime/api-documentation/variation'
output.mkdir(exist_ok=True)
recipe=b'presentation.badge(ui, "state", "Document annotation", polyorama_ui_egui::StatusTone::Success);'
commands=[['cargo','build','--release','-p','analytical-workspace-lab','--example','minimal-workspace'],['bash','tools/minimal-native-smoke.sh']]
try:
    changed=original.replace(b'// Public variation point: add a measured status badge here.',recipe,1)
    assert changed!=original
    source.write_bytes(changed)
    for i,command in enumerate(commands):
        with (output/f'command-{i}.log').open('w') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'POLYORAMA_EVIDENCE_DIR':str(output)})
        assert result.returncode==0, f'variation command failed: {command}'
finally:
    source.write_bytes(original)
assert source.read_bytes()==original
receipt={'base_source_commit':revision,'documented_delta':recipe.decode(),'source_sha256':hashlib.sha256(changed).hexdigest(),'commands':commands,'environment':'Native x86_64 Linux; eframe wgpu; Xvfb; WGPU_BACKEND=gl; bundled UI libraries; public presenter/status seam', 'result':'variation compiled; two physical Add actions preserve 0/1/2 annotation and undo counts; empty text audits','source_restored':True,'observations':['minimal-native-before.json','minimal-native-after-1.json','minimal-native-after-2.json','minimal-native-after.png','minimal-native-runtime.log']}
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
