import { chromium } from '/nvme/development/polyorama/node_modules/playwright/index.mjs';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createServer } from 'node:http';
const docRoot=resolve('target/doc');
const server=createServer(async(req,res)=>{
 try {
  const path=resolve(docRoot,'.'+decodeURIComponent(req.url.split('?')[0]));
  const mime={'.html':'text/html','.css':'text/css','.js':'text/javascript','.woff2':'font/woff2','.svg':'image/svg+xml'};
  const bytes=await readFile(path);res.writeHead(200,{'Content-Type':mime[extname(path)]??'application/octet-stream'});res.end(bytes);
 } catch {res.writeHead(404);res.end('missing');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base=`http://127.0.0.1:${server.address().port}`;
const output = resolve('.tools/runtime/api-documentation/rendered');
await mkdir(output, {recursive: true});
let browser = await chromium.launch({headless:process.env.POLYORAMA_BROWSER_HEADFUL!=='1', args:['--no-sandbox','--disable-dev-shm-usage','--disable-features=FontationsFontBackend','--disable-gpu'], executablePath:'/home/rob/.cache/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-linux64/chrome-headless-shell',env:{...process.env, LD_LIBRARY_PATH:resolve('.tools/sysroot/usr/lib'),FONTCONFIG_FILE:resolve('.tools/runtime/api-documentation/fonts.conf')}});
let page = await browser.newPage({viewport:{width:1440,height:1000}});
const errors=[];
page.on('pageerror', e=>errors.push(e.message));
const inspected=[];
for (const [crate, item, contracts] of [
 ['polyorama_core','index.html',['Application state and validated transitions','validate_intent','CommandHistory']],
 ['polyorama_runtime','index.html',['Reconcile desired tiles','take_decoded_for_renderer','take_external_request']],
 ['polyorama_render_wgpu','index.html',['renderer-owned GPU resources','UploadAdmission','maintain_frame']],
 ['polyorama_ui_egui','index.html',['application-owned pane extension','PanePresenter','PresentationContext']],
 ['polyorama_core','commands/fn.validate_intent.html',['reserves an ID','variant','human-readable']],
 ['polyorama_runtime','struct.Runtime.html',['complete desired set','original hand-off token','worker-thread']],
 ['polyorama_render_wgpu','struct.ImageRenderRequest.html',['neither schedule decoding','source_generation','desired_tiles']],
 ['polyorama_ui_egui','trait.PanePresenter.html',['narrow read models','repeated layout pass','pane_ui']],
 ['polyorama_ui_egui','struct.PresentationContext.html',['another context, viewport or pass','finish','property_row']],
]) {
 await browser.close();
 browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-features=FontationsFontBackend','--disable-gpu'],executablePath:'/home/rob/.cache/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-linux64/chrome-headless-shell',env:{...process.env,LD_LIBRARY_PATH:resolve('.tools/sysroot/usr/lib'),FONTCONFIG_FILE:resolve('.tools/runtime/api-documentation/fonts.conf')}});
 page=await browser.newPage({viewport:{width:1440,height:1000}});
 page.on('pageerror', e=>errors.push(e.message));
 const url=`${base}/${crate}/${item}`;
 await page.goto(url);
 await page.waitForLoadState('networkidle');
 await page.getByText(contracts[0],{exact:false}).first().waitFor({state:'visible',timeout:5000});
 const text=(await page.locator('body').innerText()).replace(/\s+/g,' ');
 await writeFile(`${output}/${crate}-${item.replaceAll('/','-')}.txt`,text);
 for (const contract of contracts) if (!text.includes(contract)) throw new Error(`Missing visible contract ${contract} at ${url}`);
 const name=`${crate}-${item.replaceAll('/','-')}`;
 await page.screenshot({path:`${output}/${name}.png`,fullPage:false});
 inspected.push({crate,item,title:await page.title(),contracts,links:await page.locator('main a').count()});
}
await page.goto(`${base}/polyorama_ui_egui/index.html`);
await page.getByRole('link',{name:'PanePresenter',exact:true}).first().click();
if (!page.url().endsWith('/trait.PanePresenter.html')) throw new Error(`Seam navigation failed ${page.url()}`);
await page.getByRole('link',{name:'PresentationContext',exact:true}).first().click();
if (!page.url().endsWith('/struct.PresentationContext.html')) throw new Error(`Presentation navigation failed ${page.url()}`);
if (errors.length) throw new Error(JSON.stringify(errors));
await writeFile(`${output}/inspection.json`,JSON.stringify({inspected,navigation:'UI entry → PanePresenter → PresentationContext',pageErrors:errors},null,2)+'\n');
console.log(JSON.stringify({pages:inspected.length,navigation:'passed',output}));
await browser.close();
await new Promise(resolve=>server.close(resolve));
