# Polyorama independent public reader check

Result: SUCCESS (reader stage only; final source correctness review pending).

Reader revision: 34a6cfc533ca85647761b7d72f413fa9e4d2e439, tree 8eff8f7c930cac04c2da8c44f1fd75a9f6913a1e. The assigned earlier candidate a298badac262b531dc2db0c5beefa8528dd628b0 differs only in five plan/evidence/archive paths. README, guide, example, Rust docs and executable/build inputs are unchanged. Canonical verification was supplied by the coordinator as successful for a298; it was not rerun or independently reassessed in this reader stage.

## Public route

Started at README.md; followed its first-application link to docs/application-composition.md, then the maintained minimal-workspace.rs example. Followed guide links to docs/ui-guides/panes.md and interactions.md, and the guide's generated target/doc four-crate entrance route. Read the four rendered crate introductions plus validate_intent, Runtime::reconcile, ImageRenderRequest, PanePresenter and PresentationContext local contracts. Found `cargo xtask docs`, separate cargo doc/test commands, the native run command and the explicitly compile-only WASM command through public documentation. Read public native smoke/bootstrap/lifecycle scripts to operate the established physical automation route. Did not inspect Lab/framework implementation or author receipts.

The public material explains durable Document versus transient Session and UI focus, validated intents and trusted command execution, complete desired-demand reconciliation and stale token handling, decoded hand-off versus actual GPU residency, host device/queue versus renderer persistent resources, ordered complete render-plan publication, worker/application/callback ownership, per-pass presenter context lifetime and reason-driven repaint. The existing PanePresenter/PresentationContext seam and exact badge variation were sufficient without private explanation.

## Commands and isolation

Materialised the committed source with git archive in this scratch directory. Copied existing release dependency outputs and cached Linux UI packages/sysroot into the private source copy; Cargo rebuilt the four framework crates and application for the original build. No author files or shared target outputs were changed.

From source/:

    cargo build --release -p analytical-workspace-lab --example minimal-workspace
    POLYORAMA_EVIDENCE_DIR=<scratch>/original tools/minimal-native-smoke.sh

Applied only the guide's exact replacement at its marked variation point:

    presentation.badge(ui, "state", "Document annotation", polyorama_ui_egui::StatusTone::Success);

Then repeated the same build and smoke with POLYORAMA_EVIDENCE_DIR=<scratch>/variation. The maintained smoke starts the compiled actual application, uses xdotool physical clicks at its current action geometry, waits for displayed count and undo history, captures the actual window and cleans up both application and Xvfb.

Environment: Linux 7.2.7-arch1-1 x86_64; rustc 1.98.1 (48a229cea 2026-09-01); cargo 1.98.1 (797e8a9bc 2026-08-05); Python 3.14.4; cached pinned Linux UI sysroot; private Xvfb display :94; WGPU_BACKEND=gl; llvmpipe LLVM 22.1.8, Mesa 26.2.3-arch1.1. This proves native functional behaviour on software rendering, not hardware performance.

The first scratch smoke failed because its private /tmp mount hid the source copy located under /tmp. The private harness was adapted with `--ro-bind "$ROOT" "$ROOT"` after that mount. Its scratch X11 directory was cleared before retries. This is an isolation adaptation, not application knowledge or a consumer-code repair. Both successful runs used this same adaptation. Failed attempts are retained. A standalone Xvfb version probe outside the sysroot environment failed to locate libXfont2; the actual smoke runs loaded the documented sysroot successfully.

## Observed outcome

Both original and variation built successfully and completed physical Add actions. Retained before/after snapshots show annotations = displayed_count = undo_entries at 0, 1 and 2, with empty text_audit arrays throughout. Opened both final PNGs: original has a readable Triangles tab, Add triangle button, count 2 and two blue offset triangles; variation additionally displays the Document annotation badge beneath the count with no overlap or clipping. Final process check found no remaining owned application/Xvfb/wrapper processes.

Opened retained rendered images for all four crate entrance pages and PresentationContext. These show legible explanatory prose/code blocks, crate navigation, composition-guide links and local pass/ownership contracts. These images were authored earlier and are inspection evidence, not newly generated reviewer captures; actual HTML text was also read from target/doc. The discovered image directory is .tools/runtime/api-documentation/rendered (the supplied api-documentation-rendered path was absent).

## Evidence

- identity.json binds revision, tree and original/variation example SHA-256.
- build-original/command-log-ga3gy5f4/{output.log,outcome.json}: successful original build (21.58 seconds).
- original/command-log-ul4_tkiw/{output.log,outcome.json}: successful physical smoke.
- build-variation/command-log-7xshjr1t/{output.log,outcome.json}: successful variation build (8.67 seconds).
- variation/command-log-pcbyzzrm/{output.log,outcome.json}: successful physical smoke.
- original/ and variation/: minimal-native-before.json, minimal-native-after-1.json, minimal-native-after-2.json, minimal-native-after.png, runtime and Xvfb logs.
- source/: exact candidate source plus documented example variation and private harness mount adaptation.

No blocking reader gap found. WASM compilation evidence remains separate, supplied through prior canonical verification; this stage makes no browser-runtime, asynchronous scalar-image runtime, physical-GPU performance or source-correctness approval claim. Final exact-head source review remains pending.
