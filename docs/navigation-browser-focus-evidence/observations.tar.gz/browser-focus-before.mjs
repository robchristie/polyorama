import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
const path='tools/navigation-browser-smoke.mjs';
const text=await readFile(path,'utf8');
const start=text.indexOf('async function focus(destination) {');
const end=text.indexOf('async function record(',start);
assert(start>=0&&end>start);
const production=text.slice(start,end);
let dispatches=0;const waits=[];
const target=async()=>({node:{focused:waits.length===45}});
const page={keyboard:{press:async key=>{assert.equal(key,'Tab');dispatches++;}},waitForTimeout:async ms=>{waits.push(ms);}};
const record={source:path,source_sha256:createHash('sha256').update(text).digest('hex'),expected:'target reached after final permitted action is accepted'};
try{
 await vm.runInNewContext(`(async()=>{${production}\nawait focus('tasks');})()`,{target,page});
 assert.equal(dispatches,45);assert.deepEqual(waits,Array(45).fill(60));record.passed=true;
} catch(error){record.failure=String(error);throw error;}
finally{record.dispatches=dispatches;record.waits=waits;await writeFile('/nvme/development/polyorama-rust-1-99-0-evidence/browser-focus-before-probe.json',JSON.stringify(record,null,2)+'\n');}
