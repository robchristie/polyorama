import subprocess
commands = [
 ['cargo','+1.97.1','check','--locked','--workspace','--all-targets','--all-features'],
 ['cargo','+1.97.1','check','--locked','--target','wasm32-unknown-unknown','-p','analytical-workspace-lab','-p','polyorama-gallery','-p','polyorama-tile-worker','-p','emuella-viewer'],
 ['cargo','+1.97.1','test','--locked','-p','emuella-viewer-source'],
]
subprocess.run(['rustc','+1.97.1','-Vv'],check=True)
for command in commands:
 print('COMMAND',repr(command),flush=True)
 subprocess.run(command,check=True)
