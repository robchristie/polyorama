import json, os, platform, subprocess, sys, time
from pathlib import Path
name, *command = sys.argv[1:]
root = Path.cwd()
out = Path('/nvme/development/polyorama-rust-1.98.1-evidence')
def output(*args): return subprocess.check_output(args, text=True).strip()
record = {
    'name': name, 'command': command, 'cwd': str(root),
    'revision': output('git','rev-parse','HEAD'),
    'tree': output('git','rev-parse','HEAD^{tree}'),
    'status_before': output('git','status','--porcelain'),
    'host': platform.platform(),
    'rustc': output('rustc','-Vv'), 'cargo': output('cargo','-V'),
    'node': output('node','--version'), 'npm': output('npm','--version'),
    'wasm_bindgen': output('wasm-bindgen','--version'),
    'environment': {k:os.environ[k] for k in ('RUSTUP_TOOLCHAIN','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','LD_LIBRARY_PATH','POLYORAMA_USE_SYSTEM_UI_LIBS','POLYORAMA_BROWSER_HEADFUL','DISPLAY') if k in os.environ},
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
}
start=time.monotonic()
with (out / f'{name}.log').open('w') as log:
    log.write(json.dumps(record,indent=2)+'\n');log.flush()
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,elapsed_seconds=round(time.monotonic()-start,3),finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),status_after=output('git','status','--porcelain'))
(out / f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
if result.returncode:
    lines=(out/f'{name}.log').read_text().splitlines(); print('\n'.join(lines[-60:]))
sys.exit(result.returncode)
