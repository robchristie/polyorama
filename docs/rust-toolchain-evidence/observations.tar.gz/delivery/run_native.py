import hashlib,json,os,re,socket,subprocess,time,urllib.request
from pathlib import Path
root=Path.cwd(); evidence=Path('/nvme/development/polyorama-rust-1.98.1-evidence');out=evidence/'repaired-native-viewer';out.mkdir(exist_ok=False)
fixtures=json.loads((evidence/'fixtures/generation.json').read_text()); assert fixtures['completed']
manifest=json.loads((root/'target/browser-production/manifest.json').read_text())
web=root/'target/browser-production/viewer'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
record={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'rustc':subprocess.check_output(['rustc','-Vv'],text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'native_binary_sha256':sha(root/'target/release/emuella-viewer'),'service_binary_sha256':sha(root/'target/release/emuella-viewer-tools'),'production_manifest_sha256':sha(root/'target/browser-production/manifest.json'),'production_source_identity':manifest['sourceIdentity'],'fixture_manifest_sha256':[sha(evidence/'fixtures'/s['target']/'manifest.json') for s in fixtures['sources']],'requested_native_route':'OpenGL Mesa llvmpipe under isolated bundled Xvfb','requested_browser_route':'software SwiftShader WebGPU using maintained launch helper','completed':False,'commands':[]}
(out/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
service_cmd=[str(root/'target/release/emuella-viewer-tools'),'serve','--listen','127.0.0.1:0','--verify-payload','true','--web',str(web)]
for source in fixtures['sources']: service_cmd+=['--representation',str(evidence/'fixtures'/source['target'])]
record['commands'].append(service_cmd)
service_log=(out/'service.log').open('w'); service=subprocess.Popen(service_cmd,stdout=service_log,stderr=subprocess.STDOUT)
xvfb=None
try:
    deadline=time.monotonic()+30
    while True:
        text=(out/'service.log').read_text();match=re.search(r'listening http://(127\.0\.0\.1:\d+)',text)
        if match: break
        if service.poll() is not None or time.monotonic()>deadline: raise RuntimeError('service failed to become ready: '+text)
        time.sleep(.1)
    url='http://'+match[1];record['service_url']=url
    with urllib.request.urlopen(url+'/catalogue') as response: catalogue=json.load(response)
    assert len(catalogue)==9
    (out/'catalogue.json').write_text(json.dumps(catalogue,indent=2)+'\n')
    tmp=out/'x11-tmp';tmp.mkdir(mode=0o1777);tmp.chmod(0o1777);(tmp/'.X11-unix').mkdir(mode=0o1777);(tmp/'.X11-unix').chmod(0o1777)
    sysroot=root/'.tools/sysroot';env=os.environ.copy();env['LD_LIBRARY_PATH']=str(sysroot/'usr/lib')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '');env['DISPLAY']=':19781';env['WGPU_BACKEND']='gl';env['RUST_LOG']='info'
    sandbox=['bwrap','--unshare-pid','--die-with-parent','--ro-bind','/','/','--bind',str(tmp),'/tmp','--ro-bind','/usr/bin','/opt','--ro-bind',str(sysroot/'usr/bin'),'/usr/bin','--bind',str(out),str(out),'--dev-bind','/dev','/dev','--proc','/proc']
    xcommand=sandbox+[str(sysroot/'usr/bin/Xvfb'),env['DISPLAY'],'-screen','0','1440x900x24','-nolisten','tcp','+extension','GLX']
    record['commands'].append(xcommand)
    xlog=(out/'xvfb.log').open('w');xvfb=subprocess.Popen(xcommand,stdout=xlog,stderr=subprocess.STDOUT,env=env)
    time.sleep(1);assert xvfb.poll() is None
    native_cmd=sandbox+[str(root/'target/release/emuella-viewer'),'--server',url,'--script-output',str(out/'native.json')]
    record['commands'].append(native_cmd);start=time.monotonic()
    with (out/'native.log').open('w') as log:subprocess.run(native_cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=720,check=True)
    record['native_elapsed_seconds']=round(time.monotonic()-start,3)
    native=json.loads((out/'native.json').read_text());stages=json.loads((out/'native.json.stages.json').read_text());workload=json.loads((root/'apps/emuella-viewer/qualification-workload.json').read_text())
    assert native['script_complete'] and native['script_step']==len(workload)
    assert len(stages)==len(workload)+1
    assert [s['phase_label'] for s in stages]==['empty-client-overview']+[s['label'] for s in workload]
    assert all(not s['errors'] and s['phase_settled_ms'] is not None and s['desired']>0 and s['ready_demands']==s['desired'] and s['in_flight']==0 for s in stages)
    assert not native['errors'] and native['image_count']==9 and native['bookmarks']>=5 and native['comparison_image'] is not None
    record['native_adapter']=native['gpu_adapter'];record['native_stages']=len(stages)
    print('native viewer passed',len(stages),'settled stages; adapter',native['gpu_adapter'],flush=True)
    record['completed']=True

finally:
    for process in (xvfb,service):
        if process is not None and process.poll() is None:
            process.terminate()
            try: process.wait(timeout=10)
            except subprocess.TimeoutExpired: process.kill();process.wait()
    record['process_cleanup']={'service_exit':service.poll(),'xvfb_exit':xvfb.poll() if xvfb else None}
    (out/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
