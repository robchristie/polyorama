import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
root=Path.cwd(); scratch=Path('/nvme/development/polyorama-rust-1.98.1-evidence');out=root/'docs/rust-toolchain-evidence';out.mkdir(exist_ok=True)
files={}
for path in sorted(scratch.rglob('*')):
 if path.is_file() and path.suffix in ('.json','.log','.py'):
  files['delivery/'+str(path.relative_to(scratch))]=path
for path in sorted((root/'.tools/runtime/verification-evidence').rglob('*')):
 if path.is_file() and path.suffix in ('.json','.log','.txt'):
  files['canonical-generated/'+str(path.relative_to(root/'.tools/runtime/verification-evidence'))]=path
for name in ('viewer-browser-desktop.png','viewer-browser-narrow.png'):
 path=scratch/'pressure-subset-browser/browser'/name
 assert path.is_file();files['delivery/pressure-subset-browser/browser/'+name]=path
index=[]
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name,path in sorted(files.items()):
  content=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(content);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(content));index.append({'path':name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
packed=gzip.compress(buffer.getvalue(),mtime=0)
(out/'observations.tar.gz').write_bytes(packed)
(out/'archive-index.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(packed).hexdigest(),'files':index},indent=2)+'\n')
for name in ('canonical-headful.json','repaired-compatibility.json','pressure-subset-cohort.json','repaired-native-runtime.json'):
 shutil.copy2(scratch/name,out/name)
shutil.copy2(scratch/'pressure-subset-browser/identity.json',out/'browser-runtime.json')
print(json.dumps({'archive_files':len(index),'archive_bytes':len(packed),'archive_sha256':hashlib.sha256(packed).hexdigest()}))
