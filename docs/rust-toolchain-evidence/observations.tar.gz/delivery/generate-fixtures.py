import hashlib, json, subprocess, time
from pathlib import Path
root=Path('/nvme/development/polyorama-rust-1.98.1-evidence/fixtures')
record=json.loads((root/'probe.json').read_text())
tool=Path('target/release/emuella-viewer-tools').resolve()
record.update(tool_sha256=hashlib.sha256(tool.read_bytes()).hexdigest(), revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), rustc=subprocess.check_output(['rustc','-Vv'],text=True).strip(), operation='generate authored public synthetic fixtures inside task scratch; no external imagery', representations=[])
for source in record['sources']:
    destination=root/source['target']
    cmd=[str(tool),'fixture','--output',str(destination),'--target',source['target'],'--codec-revision','6586e3d50f95429b242cb2e3535742b002784f2d']
    for key in ('width','height','bits','components','tile','levels','bpp'):cmd += ['--'+key,str(source[key])]
    started=time.monotonic()
    with (root/(source['target']+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
    manifest=json.loads((destination/'manifest.json').read_text())
    hashes={str(p.relative_to(destination)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.rglob('*')) if p.is_file()}
    record['representations'].append({'command':cmd,'elapsed_seconds':round(time.monotonic()-started,3),'manifest':manifest,'file_sha256':hashes})
    (root/'generation.json').write_text(json.dumps(record,indent=2)+'\n')
    print('generated',source['target'],flush=True)
record['completed']=True
(root/'generation.json').write_text(json.dumps(record,indent=2)+'\n')
