import os,subprocess,sys,time,tempfile
from pathlib import Path
name,*command=sys.argv[1:]
root=Path.cwd();evidence=Path('/nvme/development/polyorama-rust-1.98.1-evidence');sysroot=root/'.tools/sysroot';tmp=Path(tempfile.mkdtemp(prefix='headful-x11-'+name+'-',dir=root/'.tools/runtime'));tmp.chmod(0o1777);(tmp/'.X11-unix').mkdir(mode=0o1777);(tmp/'.X11-unix').chmod(0o1777)
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(sysroot/'usr/lib')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '');env['DISPLAY']=':'+str(1000+os.getpid()%10000);env['POLYORAMA_BROWSER_HEADFUL']='1';env['POLYORAMA_USE_SYSTEM_UI_LIBS']='1';env['RUSTUP_TOOLCHAIN']='1.98.1';env['PATH']='/home/rob/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin:'+env['PATH']+':/opt'
sandbox=['bwrap','--unshare-pid','--die-with-parent','--ro-bind','/','/','--bind',str(tmp),'/tmp','--ro-bind','/usr/bin','/opt','--ro-bind',str(sysroot/'usr/bin'),'/usr/bin','--bind',str(root),str(root),'--bind',str(evidence),str(evidence),'--bind','/home/rob','/home/rob','--dev-bind','/dev','/dev','--proc','/proc']
xlog=(evidence/(name+'-xvfb.log')).open('w');xvfb=subprocess.Popen(sandbox+[str(sysroot/'usr/bin/Xvfb'),env['DISPLAY'],'-screen','0','1440x900x24','-nolisten','tcp','+extension','GLX'],stdout=xlog,stderr=subprocess.STDOUT,env=env)
try:
 time.sleep(1)
 if xvfb.poll() is not None: raise RuntimeError('headful Xvfb failed: '+(evidence/(name+'-xvfb.log')).read_text())
 if name=='canonical-headful':command=['python3',str(evidence/'run_check.py'),name,*command]
 result=subprocess.run(sandbox+command,env=env)
 sys.exit(result.returncode)
finally:
 if xvfb.poll() is None:
  xvfb.terminate()
  try:xvfb.wait(timeout=10)
  except subprocess.TimeoutExpired:xvfb.kill();xvfb.wait()
