import hashlib,json,os,re,subprocess,time,urllib.request,sys
from pathlib import Path
root=Path.cwd();evidence=Path('/nvme/development/polyorama-rust-1.98.1-evidence');out=evidence/(sys.argv[1] if len(sys.argv)>1 else 'viewer-browser-headful');out.mkdir(exist_ok=False)
fixtures=json.loads((evidence/'fixtures/generation.json').read_text());web=Path(sys.argv[2]) if len(sys.argv)>2 else root/'target/browser-production/viewer';service_tool=Path(sys.argv[3]) if len(sys.argv)>3 else root/'target/release/emuella-viewer-tools';manifest_path=web.parent/'manifest.json';manifest=json.loads(manifest_path.read_text()) if manifest_path.exists() else {'sourceIdentity':{'purpose':'uncommitted diagnostic build with explicit current source status','web_root':str(web)}}
record={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'rustc':subprocess.check_output(['rustc','-Vv'],text=True).strip(),'production_manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest() if manifest_path.exists() else None,'production_source_identity':manifest['sourceIdentity'],'requested_route':('explicit Vulkan hardware request with headless Chromium; actual adapter retained' if os.environ.get('EMUELLA_BROWSER_GPU')=='hardware' else 'headful SwiftShader WebGPU in isolated bundled Xvfb'),'completed':False,'environment':{k:os.environ[k] for k in ('DISPLAY','POLYORAMA_BROWSER_HEADFUL','POLYORAMA_USE_SYSTEM_UI_LIBS','LD_LIBRARY_PATH')}}
service_cmd=[str(service_tool),'serve','--listen','127.0.0.1:0','--verify-payload','true','--web',str(web)]
for s in fixtures['sources']:service_cmd+=['--representation',str(evidence/'fixtures'/s['target'])]
if len(sys.argv)>4:
 cohort=json.loads(Path(sys.argv[4]).read_text());record['cohort']=cohort;service_cmd=service_cmd[:service_cmd.index('--representation')];
 for entry in cohort['representations']:service_cmd+=['--representation',entry['path']]
record['service_command']=service_cmd;record['service_binary_sha256']=hashlib.sha256(service_tool.read_bytes()).hexdigest();record['browser_build_identity']=manifest['sourceIdentity']
log=(out/'service.log').open('w');service=subprocess.Popen(service_cmd,stdout=log,stderr=subprocess.STDOUT)
try:
 deadline=time.monotonic()+30
 while True:
  text=(out/'service.log').read_text();match=re.search(r'listening http://(127\.0\.0\.1:\d+)',text)
  if match:break
  if service.poll() is not None or time.monotonic()>deadline:raise RuntimeError('service failed: '+text)
  time.sleep(.1)
 url='http://'+match[1];record['service_url']=url
 with urllib.request.urlopen(url+'/catalogue') as response:catalogue=json.load(response)
 (out/'catalogue.json').write_text(json.dumps(catalogue,indent=2)+'\n')
 assert len(catalogue)==(len(record['cohort']['representations']) if 'cohort' in record else 9)
 if 'cohort' in record:
  assert [entry['tid'] for entry in catalogue] == [entry['manifest']['tid'] for entry in record['cohort']['representations']], 'service changed frozen catalogue order'
 (out/'catalogue.json').write_text(json.dumps(catalogue,indent=2)+'\n')
 env=os.environ.copy();env['POLYORAMA_EVIDENCE_DIR']=str(out/'browser');env['EMUELLA_VIEWER_URL']=url
 record['command']=(['node','.tools/runtime/viewer-trace.mjs'] if os.environ.get('VIEWER_SMOKE_TRACE') else ['cargo','xtask','viewer-smoke']);start=time.monotonic()
 with (out/'browser.log').open('w') as log:subprocess.run(record['command'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=720,check=True)
 record['elapsed_seconds']=round(time.monotonic()-start,3)
 browser=json.loads((out/'browser/viewer-browser.json').read_text());pressure=json.loads((out/'browser/viewer-browser-pressure.json').read_text())
 record['adapters']=browser['adapters'];record['workers']=browser['workers'];record['stages']=len(browser['states']);record['pressure']={'gpu_evictions':pressure['snapshot']['gpu_evictions'],'representation_evictions':pressure['snapshot']['worker']['representation_evictions'],'aborted':pressure['snapshot']['worker']['aborted']};record['completed']=True
 print('browser viewer passed',record['stages'],'stages;',record['pressure'],flush=True)
finally:
 if service.poll() is None:
  service.terminate()
  try:service.wait(timeout=10)
  except subprocess.TimeoutExpired:service.kill();service.wait()
 record['service_exit']=service.poll();(out/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
